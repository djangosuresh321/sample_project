from django.apps import AppConfig


class StudentLoginConfig(AppConfig):
    name = 'student_login'
