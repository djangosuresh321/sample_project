from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import Register_Model,Login_Details,Logout_Details
from .forms import Student_form

def register_view(request):
    if request.method == "POST":
        user1 = request.POST.get('username')
        email1 = request.POST.get('email')
        password1 = request.POST.get('password')

        data=Register_Model(
            username=user1,
            email=email1,
            password=password1
        )
        data.save()

        return render(request, 'login.html')

    else:
        return render(request, 'register.html')

from datetime import datetime
date_time=datetime.now()

def Login_view(request):
    if request.method=="POST":
        user_name= request.POST.get('username')
        password = request.POST.get('password')
        mode1=request.POST.get('user')



        user_valid=Register_Model.objects.filter(username=user_name,password=password)


        if user_valid:
            login = Login_Details(
                username=user_name,
                password=password,
                Date=date_time,
                mode=mode1
            )
            login.save()
            return redirect('home')
        else:
            data="<h1>Credentials are Not Valid</h1>"
            return HttpResponse(data)
    else:
        return render(request,'login.html')


def home(request):
    if request.method=="POST":
        form=Student_form(request.POST)
        if form.is_valid():
            feedback1=request.POST.get('feedback')

            data=Logout_Details(
                feedback=feedback1,
                date_time=date_time
            )
            data.save()
            return redirect('login')

    else:
        form=Student_form()
        return render(request, 'home.html', {'form':form,'date_time':date_time})
