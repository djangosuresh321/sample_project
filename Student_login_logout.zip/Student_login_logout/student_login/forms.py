from django import forms

class Student_form(forms.Form):
    feedback=forms.CharField(
        label="Enter Your Today Work",
        widget=forms.Textarea(
           attrs={
               'class':'form-control',
               'placeholder':'Enter Your Work'
           }
        )
    )