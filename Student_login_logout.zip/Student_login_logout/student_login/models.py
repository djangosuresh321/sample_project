from django.db import models

class Register_Model(models.Model):
    username=models.CharField(max_length=100)
    email=models.EmailField(max_length=100)
    password=models.CharField(max_length=100)

    def __str__(self):
        return self.username

class Login_Details(models.Model):
    username=models.CharField(max_length=100)
    password=models.CharField(max_length=100)
    Date=models.DateTimeField(max_length=100)
    mode=models.CharField(max_length=100)

    def __str__(self):
        return self.username

class Logout_Details(models.Model):
    feedback=models.CharField(max_length=1000)
    date_time=models.DateTimeField(max_length=100)

